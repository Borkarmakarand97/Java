package in.kgcoding.challenge80;

public class Magazine extends LibraryItem {

    private String issueNumber;

}
