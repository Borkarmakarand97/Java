package in.kgcoding.challenge80;

public class DVD extends LibraryItem {

    private int durationInSeconds;
}
