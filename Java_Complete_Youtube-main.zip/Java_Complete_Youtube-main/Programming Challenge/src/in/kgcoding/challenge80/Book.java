package in.kgcoding.challenge80;

public class Book extends LibraryItem {

    private String iSBN;

}
