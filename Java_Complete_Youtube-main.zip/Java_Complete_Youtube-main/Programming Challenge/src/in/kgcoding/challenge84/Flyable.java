package in.kgcoding.challenge84;

public interface Flyable {
    void fly();
}
