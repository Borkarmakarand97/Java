package in.kgcoding.challenge84;

public class TestFly {
    public static void main(String[] args) {
        Eagle eagle = new Eagle();
        eagle.fly();
    }
}