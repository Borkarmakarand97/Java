package in.kgcoding.challenge83;

public abstract class Shape {
    public abstract double calculateArea();
}
