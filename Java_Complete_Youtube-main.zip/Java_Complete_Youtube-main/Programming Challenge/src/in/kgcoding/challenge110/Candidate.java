package in.kgcoding.challenge110;

@FunctionalInterface
public interface Candidate {
    boolean isCandidate(int num);
}
