package in.kgcoding.challenge86;

public class Vehicle {

    public void service() {
        System.out.println("Vehicle is getting serviced....");
    }
}
