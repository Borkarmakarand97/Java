package in.kgcoding.challenge86;

public class Test {
    public static void main(String[] args) {
        Car car = new Car();
        Vehicle veh = new Vehicle();
        veh.service();
        car.service();
    }
}
