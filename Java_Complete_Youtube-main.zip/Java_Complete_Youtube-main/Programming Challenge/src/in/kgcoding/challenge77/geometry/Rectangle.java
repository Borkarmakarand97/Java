package in.kgcoding.challenge77.geometry;

public class Rectangle {

    public int length;
    public int breadth;

    public Rectangle(int length, int breadth) {
        this.length = length;
        this.breadth = breadth;
    }
}
