package in.kgcoding.challenge77.geometry;

public class Circle {
    public double radius;

    public Circle(double radius) {
        this.radius = radius;
    }
}
