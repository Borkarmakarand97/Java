public class OrderOfOperation {
    public static void main(String[] args) {
        System.out.println(8-3*3);

        System.out.println(9/(3/3 + 2));
    }
}
