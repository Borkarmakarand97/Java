public class Assignment {
    public static void main(String[] args) {
        int myInt = 9;
        System.out.println(myInt);
        int newInt = myInt;
        System.out.println(newInt);

        //9 = myInt;
    }
}