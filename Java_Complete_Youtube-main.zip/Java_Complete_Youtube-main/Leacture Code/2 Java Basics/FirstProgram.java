import java.lang.*;

public class FirstProgram {
  public static void main(String[] args) {
    System.out.println("Welcome");
    System.out.println("KG");
    System.out.println("Coding");
  }
}