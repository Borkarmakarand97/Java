package FirstProject.src;
public class Main {
    public static void main(String[] args) {
        System.out.println("Welcome KG Coding");
        System.out.println("asdfasdf");
    }
}