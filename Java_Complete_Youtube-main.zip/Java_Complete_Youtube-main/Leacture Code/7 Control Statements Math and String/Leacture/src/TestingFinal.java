public class TestingFinal {

    final double PI = 3.1412;

    void testing() {
    }

    public static void main(String[] args) {

    }
}
