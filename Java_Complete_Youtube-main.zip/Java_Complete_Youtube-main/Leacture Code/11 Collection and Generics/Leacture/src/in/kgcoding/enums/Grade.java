package in.kgcoding.enums;

public enum Grade {
    A, B, C, D, E, F
}
