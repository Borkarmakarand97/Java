package in.kgcoding.wrapper;

public class TestingWrapper {
    public static void main(String[] args) {
        Integer first = 55;
        System.out.println(first);
        int second = first;

    }
}
