package in.kgcoding.abstraction;

public interface Transport {
    void getSetGo();
}
