public class Variables {
    public static void main(String[] args) {
        int myNumber = 865;
        int myNUMBER = 865;
        int yourNumber = 0;

        int asdf987 = 8;

        int uh87d87yyd87 = 90;

        System.out.println(yourNumber);
        yourNumber = 865;
        System.out.println(yourNumber);
        yourNumber = 45;
        System.out.println(yourNumber);

        float myFloat = 5.0f;
        double myDouble = 6.98766;
        System.out.println(myFloat);

        boolean isVegetarian = true;
        System.out.println(isVegetarian);

        String wishes = "Good Morning";
        System.out.println(wishes);

        char myCharacter = 'K';



    }
}