public class Escape {
    public static void main(String[] args) {
        System.out.println("Hello\bKGCoding...");
    }
}
