public class Comments {
    /**
     * This is my main method
     * @param args
     */
    public static void main(String[] args) {
        // this is important, don't delete this
        System.out.println("Hello world!");

        /*
        this is the first line of the comment
        the comment is still continuing
         */
        int a = 5;
    }
}