package in.kgcoding;

class Default {
}
