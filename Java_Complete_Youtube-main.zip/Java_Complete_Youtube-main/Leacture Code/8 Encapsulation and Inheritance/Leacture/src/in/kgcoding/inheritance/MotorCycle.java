package in.kgcoding.inheritance;

import in.kgcoding.TwoWheeler;

public class MotorCycle extends TwoWheeler {
    public double petrolCapacity;

    public void start() {
        System.out.println("Starting");
    }
}
