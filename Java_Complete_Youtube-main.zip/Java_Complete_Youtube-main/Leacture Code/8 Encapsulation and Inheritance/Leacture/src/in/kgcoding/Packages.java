package in.kgcoding;

import java.util.Scanner;

public class Packages {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        in.knowledgegate.Packages packages = new in.knowledgegate.Packages();
    }
}