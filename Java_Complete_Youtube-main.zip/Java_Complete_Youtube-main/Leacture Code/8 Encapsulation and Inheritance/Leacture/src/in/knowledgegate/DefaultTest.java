package in.knowledgegate;

import in.kgcoding.Car;

public class DefaultTest {
    public static void main(String[] args) {
        Car car = new Car("Yellow", "Dezire",
                5, 3000);
        //car.costOfPurchase = 8;
        // in.kgcoding.Default def;
    }
}
